import SwiftUI
struct IntrestGroupView: View {
    var body: some View {
        VStack{
            Color(UIColor(red: 250/255, green: 240/255, blue: 180/255, alpha: 1.0))
                .ignoresSafeArea() // Ensure the color extends to the edges
            
            Text("Hello, World!")
            
        }
    }
}
