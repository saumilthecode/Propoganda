import SwiftUI

struct HowToGetToBBSSView: View {
    var body: some View {
        ZStack{
            Color(UIColor(red: 250/255, green: 240/255, blue: 180/255, alpha: 1.0))
                .ignoresSafeArea()
            
            Text("How to get to BBSS")
                .font(.title)
                .padding()
        }
        .foregroundColor(.black)
    }

}
